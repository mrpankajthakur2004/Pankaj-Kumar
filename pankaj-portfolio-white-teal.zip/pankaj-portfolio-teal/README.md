# Pankaj Kumar — White & Teal Portfolio

## Files
- `index.html` — page structure and content
- `style.css` — white / ice-blue / teal visual theme and responsive layout
- `script.js` — mobile menu, active navigation, scroll reveal and project filters

## Run locally
Open `index.html` in a browser, or run:
```bash
python -m http.server 8080
```
Then visit `http://localhost:8080`.

## Add your portrait
In `index.html`, find `.portrait-placeholder`. Replace that placeholder `<div>` with:
```html
<img class="profile-photo" src="assets/pankaj-profile.png" alt="Pankaj Kumar">
```
Then add this CSS rule:
```css
.profile-photo { width: 100%; height: 100%; object-fit: cover; object-position: center top; }
```
Create an `assets` folder and put your portrait there.

## Customize
Update project URLs, stats, services, social links, email, and timeline details in `index.html` before publishing.
